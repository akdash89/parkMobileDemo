package com.park.automationframework.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.log4testng.Logger;

import com.park.automationframework.exception.ActionBotException;

import io.appium.java_client.AppiumDriver;

public class DriverCommonLib 
{

	static Logger logger = Logger.getLogger(DriverCommonLib.class);
	//public static int timeOut = Integer.parseInt(ConfigReader.getProperty("config.properties", "TIMEOUT"));

	static Dimension dSize = null;
	

	// wait untill entire page is loaded
	public  static void waitForPageLoad(RemoteWebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(60000, TimeUnit.SECONDS);
		
	}
	
	

	// wait untill perticular element is present in ui
	public static WebElement waitForElementPresent(RemoteWebDriver driver, WebElement wb) 
	{
		WebDriverWait wait = new WebDriverWait(driver, 30000);
		wait.until(ExpectedConditions.visibilityOf(wb));
		return wb;
	}
	
	
	// method will click on the web element provided
	
	public static void click(AppiumDriver driver, WebElement wb) throws ActionBotException {
		
		WebElement element;
		
		try {
			element = waitForElementPresent(driver, wb);
			if (element != null)
			{
				element.click();
			} 
			
		   else
		   {
				logger.error("Element is Null Hence Unable To Click ON ELEMENT");
			}
			// to print http request/response
			// HttpClientUtilities.printRequestResponse(driver.getCurrentUrl());
		   } 
		catch (ElementNotVisibleException e)
		{
			logger.error("Element Not Clickable Exception has occurred.. Locating element again ");
			try 
			{
				moveToElementAndClick(driver, wb);
			} 
			catch (Exception exx) 
			{
				throw new ActionBotException
				(
						"\n Exception in Click Method While performing click on " + wb.toString() + " => \n" + exx,
						exx);
			}
		} 
		catch (StaleElementReferenceException ex)
		{
			logger.error("Stale Element Reference Exception has occurred.. Locating element again ");
		
		} catch (Exception e)
		{
			throw new ActionBotException(
					"\n Exception in Click Method While performing click on " + wb.toString() + " =>\n" + e, e);

		}
	}
	
	
	//move to perticular element and click

	public static void moveToElementAndClick(RemoteWebDriver driver, WebElement element) throws ActionBotException {
		Actions actions = new Actions(driver);
		try {
			actions.moveToElement(element).click().build().perform();
		} catch (StaleElementReferenceException ex)
		{
			logger.error("Stale Element Reference Exception has occurred... Locating element again... ");
			try {
				actions.moveToElement(element).click().build().perform();
			} catch (Exception exx) {
				throw new ActionBotException("\n Exception in Click Method While performing click on " + " =>"
						+ element.toString() + " \n" + exx, exx);
			}
		} catch (Exception e) {
			throw new ActionBotException(
					"\n Exception in Click Method While performing click on " + " =>" + element.toString() + " \n" + e,
					e);
		}
	}
	
	//type on editbox
	 public static void sendKeys(AppiumDriver driver, WebElement element, String text)
			    throws ActionBotException
			  {
			    String value = null;
			    try
			    {
			     
			      element.clear();
			     
			      element.sendKeys(text);
			      
			      driver.hideKeyboard();
			      //value = element.getAttribute("value");
			    }
			    catch (Exception e)
			    {
			      throw new ActionBotException("EXCEPTION IN SENDKEYS " + e, e);
			    }
			    //return value;
			  }
	
	//get ui text
	 public static String get_UI_Text(RemoteWebDriver driver, WebElement element) throws ActionBotException
	 {
		 String val=null;
		 try
		 {
			val= element.getText();
		 }
		 catch(Exception e)
	 {
			 throw new ActionBotException("EXCEPTION IN get_UI_Text " + e, e); 
			 
	 }
		 
		 return val;
		 
	 }
	
	
	
	

	// Type on textbox
	public static void type(RemoteWebDriver driver, WebElement editwb, String data) {
		waitForElementPresent(driver, editwb);
		editwb.clear();
		editwb.sendKeys(data);
	}

	// click on perticular element


	// Select drop down by visible text
	public  static void select(WebElement selectwb, String data) {
		Select sel = new Select(selectwb);
		sel.selectByVisibleText(data);
	}

	// Select drop down by index
	public static void select(WebElement selectwb, int index) {
		Select sel = new Select(selectwb);
		sel.selectByIndex(index);
	}

	// Swipe from right to left
	public static void swipeRightToLeft(AppiumDriver driver, double startX, double endX) {
		try {
			dSize = driver.manage().window().getSize();

			int startx = (int) (dSize.width * startX);

			int endx = (int) (dSize.width * endX);

			int starty = dSize.height / 2;

			driver.swipe(startx, starty, endx, starty, 3000);
		}

		catch (Exception ex)

		{
			ex.printStackTrace();
		}

	}

	// swipe right to left
	public static void swipeLeftToRight(AppiumDriver driver, double startX, double endX) {
		try {
			dSize = driver.manage().window().getSize();

			int startx = (int) (dSize.width * startX);

			int endx = (int) (dSize.width * endX);

			int starty = dSize.height / 2;

			driver.swipe(endx, starty, startx, starty, 3000);
		}

		catch (Exception ex)

		{
			ex.printStackTrace();

		}

	}

	// swipe top to bottom
	public static void swipeTopToBottm(AppiumDriver driver, double startY, double endY) {
		try {
			dSize = driver.manage().window().getSize();

			int starty = (int) (dSize.height * startY);

			int endy = (int) (dSize.height * endY);

			int startx = dSize.width / 2;

			driver.swipe(startx, endy, startx, starty, 3000);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	// swipe bottom to top
	public static void swipeBottomToTop(AppiumDriver driver, double startY, double endY) {
		try {
			dSize = driver.manage().window().getSize();

			System.out.println(dSize);

			int starty = (int) (dSize.height * startY);

			int endy = (int) (dSize.height * endY);

			int startx = dSize.width / 2;

			driver.swipe(startx, endy, startx, starty, 3000);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}

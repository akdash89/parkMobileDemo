package com.park.automationframework.util.impl;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.park.automationframework.common.Browser;
import com.park.automationframework.exception.AutomationFrameworkException;
import com.park.automationframework.util.BANK;
import com.park.automationframework.util.DriverManager;
import com.park.automationframework.util.common.ConfigReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;



public class DefaultDriverManager implements DriverManager 
{
	private static String sPropFileName = "config.properties";

    @Override
    public WebDriver getDriver() throws AutomationFrameworkException {

	// create a Web Driver and return it to the client
	String browser = ConfigReader.getProperty("config.properties", "BROWSER");
	WebDriver driver = null;

	if (browser.equals(Browser.FIREFOX)) {
	    driver = new FirefoxDriver();

	} else if (browser.equals(Browser.CHROME)) {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Resources\\chromedriver.exe");
	    driver = new ChromeDriver();

	} else if (browser.equals(Browser.IE)) {
	    driver = new InternetExplorerDriver();

	} else {
	    throw new AutomationFrameworkException("Browser [" + browser + "] Not Supported");
	}

	return driver;
    }
    
    @Override
    public AppiumDriver getMobileDriver( BANK bank) throws IOException 
    {
    	AppiumDriver driver = null;
		// String platform="Android";
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("noReset", "False");
		cap.setCapability("fullReset", "False");
		cap.setCapability("automatioNname", ConfigReader.getProperty(sPropFileName, "AUTOMATIONNAME"));
		cap.setCapability("platformName", ConfigReader.getProperty(sPropFileName, "PLATFORMNAME"));
		cap.setCapability("platformversion", ConfigReader.getProperty(sPropFileName, "PLATFORMVERSION"));
		cap.setCapability("deviceName", ConfigReader.getProperty(sPropFileName, "DEVICENAME"));
		cap.setCapability("newCommandTimeout", 10000);

		String appProperties = ConfigReader.getProperty(sPropFileName, bank.toString());
		String[] propertiesArray = appProperties.split("\\|");

		System.out.println(propertiesArray[0]);
		cap.setCapability("app", propertiesArray[0]);
		cap.setCapability("apppackage", propertiesArray[1]);
		cap.setCapability("appactivity", propertiesArray[2]);

		String appiumServerUrl = System.getProperty("APPIUM_SERVER_URL");
		if (appiumServerUrl == null) {
			appiumServerUrl = ConfigReader.getProperty(sPropFileName, "APPIUM_SERVER_URL");
		}

		driver = new AndroidDriver(new URL(appiumServerUrl), cap);

		driver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);

		return driver;
	}
	

}

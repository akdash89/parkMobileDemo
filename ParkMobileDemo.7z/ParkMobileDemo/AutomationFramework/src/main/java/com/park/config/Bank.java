package com.park.config;

public enum Bank 
{
LVB
}

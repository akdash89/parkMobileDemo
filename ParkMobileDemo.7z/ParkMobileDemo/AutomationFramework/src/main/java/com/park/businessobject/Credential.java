package com.park.businessobject;

public class Credential 
{
	// credential utility
		String username;
		String password;
		String bankname;
	    String usernameexcel;
	    String passwordexcel;
	    
		public String getBankname() {
			return bankname;
		}

		public void setRetailname(String bankname) {
			this.bankname = bankname;
		}

		public Credential() {
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
		public String getusernameexcel() {
			return usernameexcel;
		}

		public void setusernameexcel(String usernameexcel) {
			this.usernameexcel = usernameexcel;
		}
		
		public String getpasswordexcel() {
			return passwordexcel;
		}

		public void setpasswordexcel(String passwordexcel) {
			this.passwordexcel = passwordexcel;
		}

}

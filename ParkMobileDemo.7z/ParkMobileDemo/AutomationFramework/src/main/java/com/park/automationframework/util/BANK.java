package com.park.automationframework.util;

public enum BANK 
{
	BOM,CANARA,TMB,SBI, BOB, CORP, UNION, BOI,IDBI,MPOINT_B,LVB,KVB,CBOI,CSPANEL,SIB, DENA, PNB
	}

